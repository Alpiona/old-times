package trabalho;

public class Pontuacao {

}
